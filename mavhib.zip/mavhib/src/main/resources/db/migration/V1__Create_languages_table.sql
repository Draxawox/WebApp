create table languages (
    id int unsigned PRIMARY KEY AUTO_INCREMENT,
    welcomeMsg varchar(100) not null,
    code VARCHAR(3)
);
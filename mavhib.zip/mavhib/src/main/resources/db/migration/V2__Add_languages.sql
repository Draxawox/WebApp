insert into languages (welcomeMsg, code) values ('Hello', 'en');
insert into languages (welcomeMsg, code) values ('Siemanko', 'pl');
insert into languages (welcomeMsg, code) values ('guten morgen', 'de');